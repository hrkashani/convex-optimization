rng(2); % set the random seed to 2
m = 20;
n = 10;
p = 8;
R = round(rand(m,n)); 		
A = full(sprand(p,m,0.2)); 
c = 10*rand(m,1) + 20; 
b = 20*rand(p,1) + 30; 